fetch("/chatbot", {
  method: "POST",
  headers: {"Content-Type": "application/json"},
  body: JSON.stringify({ message: "Hello" })
})
.then(res => res.json())
.then(data => {
  document.getElementById("chat-area").innerText = data.response;
});
