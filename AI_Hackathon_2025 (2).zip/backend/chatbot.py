from langchain.chat_models import ChatOpenAI
from langchain.chains import ConversationChain

llm = ChatOpenAI(temperature=0.7)
chain = ConversationChain(llm=llm, verbose=True)

def get_chat_response(user_input):
    return chain.run(user_input)
