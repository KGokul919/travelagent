def handle_call(data):
    language = data.get("language", "en")
    if language == "en":
        return {"message": "Welcome to our service. Press 1 for bookings, 2 for refunds."}
    elif language == "hi":
        return {"message": "सेवा में आपका स्वागत है। बुकिंग के लिए 1 दबाएं।"}
    else:
        return {"message": "Unsupported language."}
