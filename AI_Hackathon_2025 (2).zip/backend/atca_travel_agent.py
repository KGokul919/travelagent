def travel_assistant_reply(data):
    intent = data.get("intent")
    if intent == "flight_status":
        return {"message": "Your flight AI202 is on-time, departure 6:30 PM."}
    elif intent == "hotel_info":
        return {"message": "Your hotel check-in at Radisson is at 2 PM."}
    else:
        return {"message": "Sorry, I couldn’t understand your request."}
