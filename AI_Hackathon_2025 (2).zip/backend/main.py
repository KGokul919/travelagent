from fastapi import FastAPI, Request
from chatbot import get_chat_response
from aica_voice_agent import handle_call
from atca_travel_agent import travel_assistant_reply

app = FastAPI()

@app.get("/")
def root():
    return {"message": "API running"}

@app.post("/chatbot")
async def chatbot_endpoint(request: Request):
    data = await request.json()
    return {"response": get_chat_response(data.get("message"))}

@app.post("/aica-call")
async def aica_handler(request: Request):
    data = await request.json()
    return handle_call(data)

@app.post("/atca")
async def travel_handler(request: Request):
    data = await request.json()
    return travel_assistant_reply(data)
