# AI Hospitality + Travel Assistant
## Tech Used:
- FastAPI
- OpenAI LangChain
- Twilio Voice
- Hugging Face

## Features
- Smart Concierge Chatbot (QR code access)
- Travel Companion on WhatsApp
- Real-Time Voice Bot for Bookings
- Admin Dashboard
