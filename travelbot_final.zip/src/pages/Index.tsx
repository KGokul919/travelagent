import React, { useState } from 'react';
import { Navigation } from '@/components/Navigation';
import { ChatInterface } from '@/components/ChatInterface';
import { StaffDashboard } from '@/components/StaffDashboard';
import { QRCodeGenerator } from '@/components/QRCodeGenerator';

const Index = () => {
  const [currentView, setCurrentView] = useState('chat');
  const [newRequests, setNewRequests] = useState<any[]>([]);
  const [pendingRequestsCount, setPendingRequestsCount] = useState(3);

  const handleNewRequest = (message: any) => {
    setNewRequests(prev => [message, ...prev]);
    setPendingRequestsCount(prev => prev + 1);
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'chat':
        return (
          <div className="h-[calc(100vh-120px)]">
            <ChatInterface onNewRequest={handleNewRequest} />
          </div>
        );
      case 'dashboard':
        return <StaffDashboard newRequests={newRequests} />;
      case 'qrcode':
        return (
          <div className="min-h-[calc(100vh-120px)] flex items-center justify-center bg-gradient-elegant p-6">
            <QRCodeGenerator />
          </div>
        );
      default:
        return <ChatInterface onNewRequest={handleNewRequest} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation 
        currentView={currentView}
        onViewChange={setCurrentView}
        pendingRequests={pendingRequestsCount}
      />
      {renderCurrentView()}
    </div>
  );
};

export default Index;
