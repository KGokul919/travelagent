// chatbotAPI.js (Simulated ChatGPT)
export const sendMessageToBot = async (message) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve("Thanks for reaching out! We'll help you plan your trip soon.");
    }, 1000);
  });
};