// firebase.js (Simulated)
export const saveBooking = async (booking) => {
  console.log("📦 Booking saved to Firebase:", booking);
  // Replace this with actual Firebase SDK logic
};