import React, { useState } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { saveBooking } from '../utils/firebase';

export default function BookingModal({ destination, onClose }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    await saveBooking({ destination, name, email, date });
    setSubmitted(true);
  };

  return (
    <div className='fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50'>
      <div className='bg-white p-6 rounded-xl w-full max-w-md'>
        {submitted ? (
          <div className='text-center'>
            <h2 className='text-xl font-semibold'>Booking Confirmed!</h2>
            <p className='text-gray-500'>Thank you for booking your trip to {destination}.</p>
            <Button className='mt-4' onClick={onClose}>Close</Button>
          </div>
        ) : (
          <div>
            <h2 className='text-lg font-semibold mb-2'>Book Trip to {destination}</h2>
            <Input placeholder='Your Name' value={name} onChange={e => setName(e.target.value)} className='mb-2 w-full' />
            <Input placeholder='Email' value={email} onChange={e => setEmail(e.target.value)} className='mb-2 w-full' />
            <Input type='date' value={date} onChange={e => setDate(e.target.value)} className='mb-4 w-full' />
            <div className='flex justify-end gap-2'>
              <Button variant='ghost' onClick={onClose}>Cancel</Button>
              <Button onClick={handleSubmit}>Book Now</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}