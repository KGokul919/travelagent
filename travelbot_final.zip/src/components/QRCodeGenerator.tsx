import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { QrCode, Download, Share2, Smartphone, Wifi } from 'lucide-react';

interface QRCodeGeneratorProps {
  chatUrl?: string;
}

export const QRCodeGenerator: React.FC<QRCodeGeneratorProps> = ({ 
  chatUrl = window.location.origin 
}) => {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  useEffect(() => {
    generateQRCode();
  }, [chatUrl]);

  const generateQRCode = () => {
    // Create a simple QR code representation for demo
    // In production, you'd use a library like qrcode
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;
    
    canvas.width = 200;
    canvas.height = 200;
    
    // Create a simple pattern for demo (in production use QR library)
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 200, 200);
    
    ctx.fillStyle = '#000000';
    
    // Draw QR-like pattern
    const gridSize = 20;
    const pattern = [
      [1,1,1,1,1,1,1,0,1,1],
      [1,0,0,0,0,0,1,0,0,1],
      [1,0,1,1,1,0,1,0,1,0],
      [1,0,1,1,1,0,1,0,1,1],
      [1,0,1,1,1,0,1,0,0,0],
      [1,0,0,0,0,0,1,0,1,1],
      [1,1,1,1,1,1,1,0,1,0],
      [0,0,0,0,0,0,0,0,1,1],
      [1,0,1,1,0,1,1,1,0,0],
      [0,1,1,0,1,0,1,0,1,1]
    ];
    
    for (let i = 0; i < pattern.length; i++) {
      for (let j = 0; j < pattern[i].length; j++) {
        if (pattern[i][j] === 1) {
          ctx.fillRect(j * gridSize, i * gridSize, gridSize, gridSize);
        }
      }
    }
    
    // Add logo area in center
    ctx.fillStyle = '#f3c614';
    ctx.fillRect(80, 80, 40, 40);
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('AC', 100, 105);
    
    setQrCodeDataUrl(canvas.toDataURL());
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.download = 'ai-chieftain-qr-code.png';
    link.href = qrCodeDataUrl;
    link.click();
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'AI Chieftain - Hotel Assistant',
          text: 'Scan this QR code to access your personal hotel assistant',
          url: chatUrl
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback - copy to clipboard
      navigator.clipboard.writeText(chatUrl);
    }
  };

  return (
    <Card className="max-w-md mx-auto shadow-elegant">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-xl">
          <QrCode className="h-6 w-6 text-primary" />
          Guest Access QR Code
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Scan to access AI Chieftain instantly - no app required
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* QR Code Display */}
        <div className="flex justify-center">
          <div className="bg-white p-4 rounded-lg shadow-soft border-2 border-primary/20">
            {qrCodeDataUrl ? (
              <img 
                src={qrCodeDataUrl} 
                alt="QR Code for AI Chieftain"
                className="w-48 h-48"
              />
            ) : (
              <div className="w-48 h-48 bg-muted flex items-center justify-center">
                <QrCode className="h-12 w-12 text-muted-foreground" />
              </div>
            )}
          </div>
        </div>

        {/* Instructions */}
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-sm">
            <Smartphone className="h-4 w-4 text-primary" />
            <span className="font-medium">How to use:</span>
          </div>
          <ol className="text-sm text-muted-foreground space-y-1 ml-6">
            <li>1. Open your phone's camera app</li>
            <li>2. Point it at the QR code above</li>
            <li>3. Tap the notification to open AI Chieftain</li>
            <li>4. Start chatting with your hotel assistant!</li>
          </ol>
        </div>

        {/* Features */}
        <div className="grid grid-cols-2 gap-3">
          <div className="text-center">
            <Badge variant="outline" className="w-full py-2 bg-primary/5 text-primary border-primary/20">
              <Wifi className="h-3 w-3 mr-1" />
              No App Required
            </Badge>
          </div>
          <div className="text-center">
            <Badge variant="outline" className="w-full py-2 bg-green-50 text-green-700 border-green-200">
              <QrCode className="h-3 w-3 mr-1" />
              Instant Access
            </Badge>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
          <Button 
            className="flex-1 bg-gradient-primary"
            onClick={handleShare}
          >
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>

        {/* URL Display */}
        <div className="text-center">
          <p className="text-xs text-muted-foreground mb-1">Direct Link:</p>
          <code className="text-xs bg-muted px-2 py-1 rounded break-all">
            {chatUrl}
          </code>
        </div>
      </CardContent>
    </Card>
  );
};