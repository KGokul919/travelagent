import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, Send, Phone, MessageSquare, Headphones } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type?: 'booking' | 'room-service' | 'concierge' | 'general';
}

interface ChatInterfaceProps {
  onNewRequest?: (message: Message) => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ onNewRequest }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Welcome to AI Chieftain! I'm your personal hotel assistant. How may I help you today? You can ask me about bookings, room service, local recommendations, or anything else.",
      sender: 'ai',
      timestamp: new Date(),
      type: 'general'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Initialize speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };

      recognitionInstance.onerror = () => {
        setIsListening(false);
        toast({
          title: "Voice Recognition Error",
          description: "Could not recognize speech. Please try again.",
          variant: "destructive"
        });
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, [toast]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date(),
      type: detectMessageType(inputText)
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Notify dashboard of new request
    onNewRequest?.(userMessage);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(inputText);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse.text,
        sender: 'ai',
        timestamp: new Date(),
        type: aiResponse.type
      };

      setMessages(prev => [...prev, aiMessage]);

      // Text-to-speech for AI response
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(aiResponse.text);
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 0.8;
        
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        
        speechSynthesis.speak(utterance);
      }
    }, 1000);
  };

  const handleVoiceToggle = () => {
    if (!recognition) {
      toast({
        title: "Voice Not Supported",
        description: "Voice recognition is not supported in this browser.",
        variant: "destructive"
      });
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.start();
      setIsListening(true);
    }
  };

  const detectMessageType = (text: string): Message['type'] => {
    const lowerText = text.toLowerCase();
    if (lowerText.includes('book') || lowerText.includes('reservation') || lowerText.includes('room')) {
      return 'booking';
    }
    if (lowerText.includes('room service') || lowerText.includes('food') || lowerText.includes('order')) {
      return 'room-service';
    }
    if (lowerText.includes('recommend') || lowerText.includes('nearby') || lowerText.includes('restaurant')) {
      return 'concierge';
    }
    return 'general';
  };

  const generateAIResponse = (userText: string): { text: string; type: Message['type'] } => {
    const type = detectMessageType(userText);
    
    const responses = {
      booking: [
        "I'd be happy to help you with your booking! Could you please provide your check-in and check-out dates, and how many guests will be staying?",
        "For room reservations, I can check availability and pricing. What type of room would you prefer - standard, deluxe, or suite?",
        "I can assist with your reservation. Would you like me to check our current rates and availability for your preferred dates?"
      ],
      'room-service': [
        "Our room service is available 24/7! I can help you place an order. Would you like to see our dinner menu, light bites, or beverages?",
        "I'd be delighted to assist with room service. Our chef's specials today include pan-seared salmon and prime ribeye. What would you like to order?",
        "Room service at your beck and call! Our kitchen can prepare anything from our full menu. Are you in the mood for something specific?"
      ],
      concierge: [
        "As your digital concierge, I'd be happy to provide recommendations! Are you looking for dining, entertainment, or local attractions?",
        "I have extensive knowledge of the local area. For fine dining, I recommend Le Bernardin or for casual fare, try the rooftop bistro. What type of experience interests you?",
        "Let me help you discover the best our city has to offer! Whether it's theaters, museums, or hidden gems, I can provide personalized suggestions."
      ],
      general: [
        "I'm here to make your stay exceptional! Whether you need assistance with hotel services, local recommendations, or anything else, just ask.",
        "Thank you for reaching out! I can help with bookings, room service, concierge services, and any questions about your stay. How may I assist you?",
        "As your AI hotel assistant, I'm equipped to handle all your needs. From dining reservations to wake-up calls, I'm at your service!"
      ]
    };

    const typeResponses = responses[type] || responses.general;
    const randomResponse = typeResponses[Math.floor(Math.random() * typeResponses.length)];
    
    return { text: randomResponse, type };
  };

  const getMessageTypeColor = (type: Message['type']) => {
    switch (type) {
      case 'booking': return 'bg-blue-100 text-blue-800';
      case 'room-service': return 'bg-green-100 text-green-800';
      case 'concierge': return 'bg-purple-100 text-purple-800';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-full bg-gradient-elegant">
      {/* Header */}
      <div className="bg-gradient-secondary p-6 shadow-elegant">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-secondary-foreground mb-1">AI Chieftain</h1>
            <p className="text-secondary-foreground/80">Your Personal Hotel Assistant</p>
          </div>
          <div className="flex gap-2">
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              <MessageSquare className="w-3 h-3 mr-1" />
              Chat Mode
            </Badge>
            {isSpeaking && (
              <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200 animate-pulse">
                <Headphones className="w-3 h-3 mr-1" />
                Speaking
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[70%] ${message.sender === 'user' ? 'order-2' : 'order-1'}`}>
              <Card className={`p-4 ${
                message.sender === 'user' 
                  ? 'bg-gradient-primary text-primary-foreground shadow-elegant' 
                  : 'bg-card shadow-soft'
              }`}>
                <div className="space-y-2">
                  {message.type && message.type !== 'general' && (
                    <Badge className={`text-xs ${getMessageTypeColor(message.type)}`}>
                      {message.type.replace('-', ' ').toUpperCase()}
                    </Badge>
                  )}
                  <p className="text-sm leading-relaxed">{message.text}</p>
                  <p className={`text-xs ${
                    message.sender === 'user' ? 'text-primary-foreground/70' : 'text-muted-foreground'
                  }`}>
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </Card>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-6 bg-card shadow-soft border-t">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Input
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type your message or use voice..."
              className="pr-12 bg-input border-border focus:ring-primary"
            />
            <Button
              size="sm"
              variant="ghost"
              className={`absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 p-0 ${
                isListening ? 'text-red-500 animate-pulse-gold' : 'text-muted-foreground hover:text-primary'
              }`}
              onClick={handleVoiceToggle}
            >
              {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
          </div>
          <Button 
            onClick={handleSendMessage}
            disabled={!inputText.trim()}
            className="bg-gradient-primary hover:bg-primary-hover shadow-elegant"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInputText("I'd like to make a reservation")}
            className="text-xs"
          >
            Make Reservation
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInputText("I'd like to order room service")}
            className="text-xs"
          >
            Room Service
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInputText("Can you recommend nearby restaurants?")}
            className="text-xs"
          >
            Local Recommendations
          </Button>
        </div>
      </div>
    </div>
  );
};