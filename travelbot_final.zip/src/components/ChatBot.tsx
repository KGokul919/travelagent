import React, { useState } from 'react';
import { sendMessageToBot } from '../utils/chatbotAPI';

export default function ChatBot() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([{ from: 'bot', text: "Hi! I'm TravelBot. How can I help you today?" }]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMsg = { from: 'user', text: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    const botResponse = await sendMessageToBot(input);
    setMessages((prev) => [...prev, { from: 'bot', text: botResponse }]);
  };

  return (
    <div className='fixed bottom-4 right-4 z-50'>
      {open && (
        <div className='w-80 h-96 bg-white rounded-xl shadow-xl p-4 flex flex-col'>
          <div className='flex justify-between items-center mb-2'>
            <h4 className='font-semibold'>TravelBot</h4>
            <button onClick={() => setOpen(false)}>✖</button>
          </div>
          <div className='flex-1 overflow-y-auto text-sm text-gray-700 mb-2'>
            {messages.map((msg, i) => (
              <p key={i} className={`mb-1 ${msg.from === 'bot' ? 'text-left' : 'text-right text-blue-600'}`}>
                {msg.text}
              </p>
            ))}
          </div>
          <div className='flex gap-2'>
            <input
              type='text'
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className='flex-1 px-3 py-2 border rounded'
              placeholder='Ask me anything...'
            />
            <button onClick={sendMessage} className='bg-blue-600 text-white px-3 py-2 rounded'>Send</button>
          </div>
        </div>
      )}
      <button className='bg-blue-600 text-white px-4 py-2 rounded-full shadow-lg' onClick={() => setOpen(!open)}>
        💬 Chat
      </button>
    </div>
  );
}