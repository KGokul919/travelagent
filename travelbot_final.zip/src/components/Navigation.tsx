import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, BarChart3, QrCode, Users, Crown, Headphones } from 'lucide-react';

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
  pendingRequests?: number;
}

export const Navigation: React.FC<NavigationProps> = ({ 
  currentView, 
  onViewChange, 
  pendingRequests = 0 
}) => {
  const navItems = [
    {
      id: 'chat',
      label: 'Guest Chat',
      icon: MessageSquare,
      description: 'Voice & text assistant'
    },
    {
      id: 'dashboard',
      label: 'Staff Dashboard',
      icon: BarChart3,
      description: 'Monitor requests',
      badge: pendingRequests > 0 ? pendingRequests.toString() : undefined
    },
    {
      id: 'qrcode',
      label: 'QR Access',
      icon: QrCode,
      description: 'Generate guest QR codes'
    }
  ];

  return (
    <nav className="bg-gradient-secondary shadow-elegant border-b">
      <div className="container mx-auto px-6 py-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-primary p-2 rounded-lg shadow-luxury">
              <Crown className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-secondary-foreground">AI Chieftain</h1>
              <p className="text-sm text-secondary-foreground/80">LLM Chatbot for Hospitality</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              <Users className="w-3 h-3 mr-1" />
              Live System
            </Badge>
            <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
              <Headphones className="w-3 h-3 mr-1" />
              Voice Ready
            </Badge>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <Button
                key={item.id}
                variant={isActive ? "default" : "outline"}
                className={`relative flex items-center gap-2 ${
                  isActive 
                    ? 'bg-gradient-primary shadow-elegant text-primary-foreground' 
                    : 'bg-card/50 text-secondary-foreground border-secondary-foreground/20 hover:bg-card'
                }`}
                onClick={() => onViewChange(item.id)}
              >
                <Icon className="h-4 w-4" />
                <div className="flex flex-col items-start">
                  <span className="text-sm font-medium">{item.label}</span>
                  <span className={`text-xs ${
                    isActive ? 'text-primary-foreground/80' : 'text-muted-foreground'
                  }`}>
                    {item.description}
                  </span>
                </div>
                {item.badge && (
                  <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs min-w-[1.25rem] h-5 flex items-center justify-center rounded-full animate-pulse-gold">
                    {item.badge}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};